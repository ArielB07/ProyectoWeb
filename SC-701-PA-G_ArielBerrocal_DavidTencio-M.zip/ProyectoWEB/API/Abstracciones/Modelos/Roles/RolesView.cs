﻿namespace Abstracciones.Modelos.Roles
{
    public class RolesView
    {
        public int Id { get; set; }

        public string? Tipo { get; set; }

        public Guid IdPersona { get; set; }
    }
}
