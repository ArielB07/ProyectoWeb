﻿using System.ComponentModel.DataAnnotations;

namespace Abstracciones.Modelos
{
    public class Pagina
    {
        public string? Nombre { get; set; }

        [Required(ErrorMessage = "La url es obligatoria.")]
        public string? Url { get; set; }

        [Required(ErrorMessage = "El id persona es obligatorio.")]
        public Guid IdPersona { get; set; }
        public string? Imagen { get; set; }

        [Required(ErrorMessage = "El id de la categoria es obligatorio.")]
        public int IdCategoria { get; set; }
    }
}