﻿using Abstracciones.Modelos;

namespace Abstracciones.BW
{
    public interface ICategoriaBW
    {
        public Task<IEnumerable<Categoria>> ObtenerTodos();
        public Task<bool> Agregar(Categoria categoria);
    }
}