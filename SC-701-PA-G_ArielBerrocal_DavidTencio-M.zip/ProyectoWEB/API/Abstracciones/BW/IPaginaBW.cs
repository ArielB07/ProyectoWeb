﻿using Abstracciones.Modelos;

namespace Abstracciones.BW
{
    public interface IPaginaBW
    {
        public Task<IEnumerable<Pagina>> ObtenerTodos(Guid idPersona);
        public Task<IEnumerable<Pagina>> ObtenerTodosPorUnaCategoria(Guid idPersona, int idCategoria);
        public Task<bool> Agregar(Pagina pagina);
    }
}