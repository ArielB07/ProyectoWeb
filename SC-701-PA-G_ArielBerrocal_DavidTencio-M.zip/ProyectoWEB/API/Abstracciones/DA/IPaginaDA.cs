﻿using Abstracciones.Modelos;

namespace Abstracciones.DA
{
    public interface IPaginaDA
    {
        public Task<bool> Agregar(Pagina pagina);
        public Task<IEnumerable<Pagina>> ObtenerTodos(Guid idPersona);
        public Task<IEnumerable<Pagina>> ObtenerTodosPorUnaCategoria(Guid idPersona, int idCategoria);
    }
}