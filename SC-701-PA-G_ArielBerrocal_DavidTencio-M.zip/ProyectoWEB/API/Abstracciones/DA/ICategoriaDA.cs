﻿using Abstracciones.Modelos;

namespace Abstracciones.DA
{
    public interface ICategoriaDA
    {
        public Task<bool> Agregar(Categoria categoria);
        public Task<IEnumerable<Categoria>> ObtenerTodos();
    }
}