﻿using Abstracciones.Modelos;
using Microsoft.AspNetCore.Mvc;

namespace Abstracciones.API
{
    public interface ICategoriaAPI
    {
        public Task<IActionResult> ObtenerTodos();
        public Task<IActionResult> Agregar([FromBody] Categoria categoria);
    }
}