﻿using Abstracciones.Modelos;
using Microsoft.AspNetCore.Mvc;

namespace Abstracciones.API
{
    public interface IPaginaAPI
    {
        public Task<IActionResult> ObtenerTodos(Guid idPersona);
        public Task<IActionResult> ObtenerTodosPorUnaCategoria(Guid idPersona, int idCategoria);
        public Task<IActionResult> Agregar([FromBody] Pagina pagina);
    }
}