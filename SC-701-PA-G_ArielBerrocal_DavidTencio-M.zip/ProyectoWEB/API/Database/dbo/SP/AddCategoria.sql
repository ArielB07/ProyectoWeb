﻿CREATE PROCEDURE [dbo].[AddCategoria]
    @Nombre VARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO Categorias (Nombre)
		VALUES (@Nombre);

        COMMIT TRANSACTION;

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        THROW;
    END CATCH
END