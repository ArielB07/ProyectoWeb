﻿CREATE PROCEDURE [dbo].[AddPagina]
    @Nombre VARCHAR(50),
	@Url VARCHAR(MAX),
	@Imagen VARCHAR(MAX),
	@IdPersona UNIQUEIDENTIFIER,
	@IdCategoria INT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO Paginas (Nombre, URL, Imagen, IdPersona, IdCategoria)
		VALUES (@Nombre, @Url, @Imagen, @IdPersona, @IdCategoria);

        COMMIT TRANSACTION;

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        THROW;
    END CATCH
END