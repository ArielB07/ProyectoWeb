﻿CREATE TABLE Categorias (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Nombre      VARCHAR (50)  NOT NULL,
	[Order]  INT  NULL
);