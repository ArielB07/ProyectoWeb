﻿CREATE TABLE Roles (
    Id int PRIMARY KEY,
    Tipo VARCHAR(100) NOT NULL
);