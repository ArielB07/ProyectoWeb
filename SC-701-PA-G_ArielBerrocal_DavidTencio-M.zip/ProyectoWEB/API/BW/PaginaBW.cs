﻿using Abstracciones.BW;
using Abstracciones.DA;
using Abstracciones.Modelos;

namespace BW
{
    public class PaginaBW : IPaginaBW
    {
        private IPaginaDA _paginaDA;

        public PaginaBW(IPaginaDA paginaDA)
        {
            _paginaDA = paginaDA;
        }

        public async Task<bool> Agregar(Pagina pagina)
        {
            return await _paginaDA.Agregar(pagina);
        }

        public async Task<IEnumerable<Pagina>> ObtenerTodos(Guid idPersona)
        {
            return await _paginaDA.ObtenerTodos(idPersona);
        }

        public async Task<IEnumerable<Pagina>> ObtenerTodosPorUnaCategoria(Guid idPersona, int idCategoria)
        {
            return await _paginaDA.ObtenerTodosPorUnaCategoria(idPersona, idCategoria);
        }
    }
}