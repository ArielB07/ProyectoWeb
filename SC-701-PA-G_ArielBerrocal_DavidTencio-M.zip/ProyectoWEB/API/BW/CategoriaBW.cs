﻿using Abstracciones.BW;
using Abstracciones.DA;
using Abstracciones.Modelos;

namespace BW
{
    public class CategoriaBW : ICategoriaBW
    {
        private ICategoriaDA _categoriaDA;

        public CategoriaBW(ICategoriaDA categoriaDA)
        {
            _categoriaDA = categoriaDA;
        }

        public async Task<bool> Agregar(Categoria categoria)
        {
            return await _categoriaDA.Agregar(categoria);
        }

        public async Task<IEnumerable<Categoria>> ObtenerTodos()
        {
            return await _categoriaDA.ObtenerTodos();
        }
    }
}