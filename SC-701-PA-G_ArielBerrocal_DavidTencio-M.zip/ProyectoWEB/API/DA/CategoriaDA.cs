﻿using Abstracciones.DA;
using Abstracciones.Modelos;
using Dapper;
using Microsoft.Data.SqlClient;

namespace DA
{
    public class CategoriaDA : ICategoriaDA
    {
        private IRepositorioDapper _repositorioDapper;

        private SqlConnection _sqlConnection;

        public CategoriaDA(IRepositorioDapper repositorioDapper)
        {
            _repositorioDapper = repositorioDapper;
            _sqlConnection = _repositorioDapper.ObtenerRepositorioDapper();
        }

        public async Task<bool> Agregar(Categoria categoria)
        {
            string query = @"AddCategoria";
            try
            {
                await _sqlConnection.QueryAsync<Categoria>(query, new
                {
                    Nombre = categoria.Nombre,
                });
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        public async Task<IEnumerable<Categoria>> ObtenerTodos()
        {
            string sql = @"SELECT * from Categorias";

            var consulta = await _sqlConnection.QueryAsync<Categoria>(sql);

            if (!consulta.Any())
                return null;

            return consulta;
        }
    }
}