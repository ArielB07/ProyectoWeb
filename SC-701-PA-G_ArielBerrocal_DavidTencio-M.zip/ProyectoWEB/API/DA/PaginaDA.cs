﻿using Abstracciones.DA;
using Abstracciones.Modelos;
using Dapper;
using Microsoft.Data.SqlClient;

namespace DA
{
    public class PaginaDA : IPaginaDA
    {
        private IRepositorioDapper _repositorioDapper;

        private SqlConnection _sqlConnection;

        public PaginaDA(IRepositorioDapper repositorioDapper)
        {
            _repositorioDapper = repositorioDapper;
            _sqlConnection = _repositorioDapper.ObtenerRepositorioDapper();
        }

        public async Task<bool> Agregar(Pagina pagina)
        {
            string query = @"AddPagina";
            try
            {
                await _sqlConnection.QueryAsync<Pagina>(query, new
                {
                    Nombre = pagina.Nombre,
                    Url = pagina.Url,
                    Imagen = pagina.Imagen,
                    IdPersona = pagina.IdPersona,
                    IdCategoria = pagina.IdCategoria
                });
            }
            catch (Exception ex)
            {
                return false;
            }

            return true;
        }

        public async Task<IEnumerable<Pagina>> ObtenerTodos(Guid idPersona)
        {
            string sql = $"SELECT * from Paginas where idPersona = '{idPersona}'";

            var consulta = await _sqlConnection.QueryAsync<Pagina>(sql);

            if (!consulta.Any())
                return null;

            return consulta;
        }

        public async Task<IEnumerable<Pagina>> ObtenerTodosPorUnaCategoria(Guid idPersona, int idCategoria)
        {
            string sql = $"SELECT * from Paginas WHERE idPersona = '{idPersona}' AND idCategoria = " + idCategoria;

            var consulta = await _sqlConnection.QueryAsync<Pagina>(sql);

            if (!consulta.Any())
                return null;

            return consulta;
        }
    }
}