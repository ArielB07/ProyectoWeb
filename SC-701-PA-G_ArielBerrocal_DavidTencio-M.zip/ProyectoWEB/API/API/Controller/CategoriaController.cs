﻿using Abstracciones.API;
using Abstracciones.BW;
using Abstracciones.Modelos;
using Microsoft.AspNetCore.Mvc;

namespace API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriaController : ControllerBase, ICategoriaAPI
    {
        private ICategoriaBW _categoriaBW;

        public CategoriaController(ICategoriaBW categoriaBW)
        {
            _categoriaBW = categoriaBW;
        }

   
        [HttpPost]
        public async Task<IActionResult> Agregar([FromBody] Categoria categoria)
        {
            var resultado = await _categoriaBW.Agregar(categoria);

            if (!resultado)
                return NoContent();

            return CreatedAtAction(nameof(ObtenerTodos), null);
        }

        [HttpGet]
        public async Task<IActionResult> ObtenerTodos()
        {
            return Ok(await _categoriaBW.ObtenerTodos());
        }
    }
}