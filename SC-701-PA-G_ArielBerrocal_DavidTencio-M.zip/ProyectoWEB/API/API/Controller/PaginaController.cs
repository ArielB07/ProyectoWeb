﻿using Abstracciones.API;
using Abstracciones.BW;
using Abstracciones.Modelos;
using Microsoft.AspNetCore.Mvc;
using System.Security.Policy;

namespace API.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaginaController : ControllerBase, IPaginaAPI
    {
        private IPaginaBW _paginaBW;

        public PaginaController(IPaginaBW paginaBW)
        {
            _paginaBW = paginaBW;
        }

        [HttpPost]
        public async Task<IActionResult> Agregar([FromBody] Pagina pagina)
        {
            using var httpClient = new HttpClient();

            var metadataService = new MetadataService(httpClient);
            try
            {
                var metadata = await metadataService.GetPageMetadataAsync(pagina.Url);
                pagina.Nombre = metadata.Title;
                pagina.Imagen = metadata.Thumbnail;
            }
            catch (Exception ex)
            {
                return NoContent();
            }

            var resultado = await _paginaBW.Agregar(pagina);

            if (!resultado)
                return NoContent();

            return Ok(resultado);
        }

        [HttpGet("todos/{idPersona}")]
        public async Task<IActionResult> ObtenerTodos([FromRoute] Guid idPersona)
        {
            return Ok(await _paginaBW.ObtenerTodos(idPersona));
        }

        [HttpGet("persona/{idPersona}/categoria/{idCategoria}")]
        public async Task<IActionResult> ObtenerTodosPorUnaCategoria([FromRoute] Guid idPersona, [FromRoute] int idCategoria)
        {
            return Ok(await _paginaBW.ObtenerTodosPorUnaCategoria(idPersona, idCategoria));
        }
    }
}