using HtmlAgilityPack;

public class PageMetadata
{
    public string Title { get; set; }
    public string Thumbnail { get; set; }
}

public class MetadataService
{
    private readonly HttpClient _httpClient;

    public MetadataService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<PageMetadata> GetPageMetadataAsync(string url)
    {
        // Validar URL
        if (!Uri.IsWellFormedUriString(url, UriKind.Absolute))
            throw new ArgumentException("La URL no es v�lida.");

        try
        {
            // Obtener el contenido HTML de la p�gina
            var response = await _httpClient.GetAsync(url);
            response.EnsureSuccessStatusCode();

            var htmlContent = await response.Content.ReadAsStringAsync();

            // Cargar el HTML en HtmlAgilityPack
            var htmlDoc = new HtmlDocument();
            htmlDoc.LoadHtml(htmlContent);

            // Extraer el t�tulo
            var titleNode = htmlDoc.DocumentNode.SelectSingleNode("//title");
            var title = titleNode?.InnerText.Trim() ?? "Sin t�tulo";

            // Extraer el thumbnail usando meta og:image
            var ogImageNode = htmlDoc.DocumentNode.SelectSingleNode("//meta[@property='og:image']");
            var thumbnail = ogImageNode?.GetAttributeValue("content", null);

            // Buscar favicon como alternativa
            if (string.IsNullOrEmpty(thumbnail))
            {
                var faviconNode = htmlDoc.DocumentNode.SelectSingleNode("//link[@rel='icon'] | //link[@rel='shortcut icon']");
                thumbnail = faviconNode?.GetAttributeValue("href", null);
            }

            // Si no hay thumbnail, asignar un valor predeterminado
            thumbnail ??= "No se encontr� thumbnail";

            return new PageMetadata
            {
                Title = title,
                Thumbnail = thumbnail
            };
        }
        catch (Exception ex)
        {
            throw new Exception($"Error al obtener metadatos: {ex.Message}");
        }
    }
}
