﻿namespace Abstracciones.Modelos.Autenticacion
{
    public class Rol
    {
        public int Id { get; set; }
        public string Tipo { get; set; }
    }
}